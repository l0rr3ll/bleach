(async () => {
  // default imports
  const events = require('events')
  const { exec } = require("child_process")
  const logs = require("discord-logs")
  const Discord = require("discord.js")
  const fetch = require('node-fetch')
  const keepAlive = require("./server");
  const {
    MessageEmbed,
    MessageButton,
    MessageActionRow,
    Intents,
    Permissions,
    MessageSelectMenu
  } = require("discord.js")
  const fs = require('fs');
  let process = require('process');
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // block imports
  const os = require("os-utils");
  let https = require("https")

  // define s4d components (pretty sure 90% of these arent even used/required)
  let s4d = {
    Discord,
    fire: null,
    joiningMember: null,
    reply: null,
    player: null,
    manager: null,
    Inviter: null,
    message: null,
    notifer: null,
    checkMessageExists() {
      if (!s4d.client) throw new Error('You cannot perform message operations without a Discord.js client')
      if (!s4d.client.readyTimestamp) throw new Error('You cannot perform message operations while the bot is not connected to the Discord API')
    }
  };

  // check if d.js is v13
  if (!require('./package.json').dependencies['discord.js'].startsWith("^13.")) {
    let file = JSON.parse(fs.readFileSync('package.json'))
    file.dependencies['discord.js'] = '^13.15.1'
    fs.writeFileSync('package.json', JSON.stringify(file, null, 4))
    exec('npm i')
    throw new Error("Seems you arent using v13 please re-run or run `npm i discord.js@13.12.0`");
  }

  // check if discord-logs is v2
  if (!require('./package.json').dependencies['discord-logs'].startsWith("^2.")) {
    let file = JSON.parse(fs.readFileSync('package.json'))
    file.dependencies['discord-logs'] = '^2.0.0'
    fs.writeFileSync('package.json', JSON.stringify(file, null, 4))
    exec('npm i')
    throw new Error("discord-logs must be 2.0.0. please re-run or if that fails run `npm i discord-logs@2.0.0` then re-run");
  }

  // create a new discord client
  s4d.client = new s4d.Discord.Client({
    intents: [
      Object.values(s4d.Discord.Intents.FLAGS).reduce((acc, p) => acc | p, 0)
    ],
    partials: [
      "REACTION",
      "CHANNEL"
    ]
  });

  // when the bot is alive, do this
  s4d.client.on('ready', async () => {
    console.log(s4d.client.user.tag + " is awake.");

    // Function to update activity
    const updateActivity = async () => {
      // Fetch the channel
      const snipeChannel = s4d.client.channels.cache.get('1181026611777261578');

      if (snipeChannel && snipeChannel.isText()) {
        // Fetch the number of messages in the channel
        const messageCount = await snipeChannel.messages.fetch().then(messages => messages.size);

        // Set the bot's activity with the message count
        s4d.client.user.setActivity(`${messageCount} snipe(s)`, { type: 'WATCHING' });
      } else {
        console.error('Could not find the specified channel or it is not a text channel.');
      }
    };

    // Initial update
    await updateActivity();

    // Schedule automatic updates every 10 minutes
    setInterval(updateActivity, 10 * 60 * 1000);

    s4d.client.user.setStatus('online');
  });

  // upon error print "Error!" and the error
  process.on('uncaughtException', function(err) {
    console.log('Error!');
    console.log(err);
  });

  // pre blockly code



  // blockly code
  const myToken = 'MTE4MDk3ODI5MDI0OTQ0MTMxMg.GlfBIS.cV17s2LSAbZe0ba4ZdKqRGhaljWeqv9fo7fFDo';
  await s4d.client.login(myToken).catch((e) => {
    const tokenInvalid = true;
    const tokenError = e;
    if (e.toString().toLowerCase().includes("token")) {
      throw new Error("An invalid bot token was provided!")
    } else {
      throw new Error("Privileged Gateway Intents are not enabled! Please go to https://discord.com/developers and turn on all of them.")
    }
  });

  const channelIdToSnipe = '1181211183655690271';
  const snipeChannelId = '1181185151645012008';

  // Function to generate a random string of 8 numbers
  function generateRandomID() {
    return Math.floor(10000000 + Math.random() * 90000000).toString();
  }

  s4d.client.on('messageCreate', async (message) => {
    // Check if the message is in the specified channel
    if (message.channel.id === channelIdToSnipe) {
      // Generate a random offset between 200 and 500 with two decimals
      const randomOffset = (Math.random() * (500 - 200) + 200).toFixed(2);

      // Generate a random ID string
      const randomID = generateRandomID();

      // Create the embed
      const snipeEmbed = {
        color: 0x1B1C21,
        title: `<:snipe:1181030020144185354> ID: #${randomID}`,
        description: `Successfully sniped \`${message.content}\` with an offset of \`${randomOffset}\` μs.`,
      };

      // Get the snipe channel
      const snipeChannel = s4d.client.channels.cache.get(snipeChannelId);

      // Send the embed to the snipe channel
      if (snipeChannel.isText()) {
        await snipeChannel.send({ embeds: [snipeEmbed] });
      }
    }
  });

  const axios = require('axios');
  const moment = require('moment');

  s4d.client.on('messageCreate', async (message) => {
    // Check if the message is in the specified channel
    if (message.channel.id === '1191447985058500679') {
      // Check if the message matches the specified format
      const regex = /^\/tm (\S+) (\d+[dmM]) (.+)$/;
      const match = message.content.match(regex);

      if (match) {
        // Extract relevant information from the matched message
        const playerName = match[1];
        const reason = match[3];
        const duration = match[2];

        // Fetch the Minecraft UUID using the Mojang API
        const mojangApiUrl = `https://api.mojang.com/users/profiles/minecraft/${playerName}`;
        let playerUUID;
        try {
          const response = await axios.get(mojangApiUrl);
          playerUUID = response.data.id;
        } catch (error) {
          console.error(`Failed to fetch UUID for player ${playerName}`);
          return;
        }

        // Calculate expiration date based on the provided duration
        const expirationDate = calculateExpirationDate(duration);
        const discordTimestamp = `<t:${Math.floor(expirationDate.unix())}:R>`;

        // Replace 'h' with ' hours' in the duration string
        const formattedDuration = duration.replace('d', ' days').replace('m', ' minutes').replace('M', ' months').replace('h', ' hours');

        // Generate a random offset between 500 and 5000 with two decimal points
        const randomOffset = (Math.random() * (5000 - 500) + 500).toFixed(2);

        // Create the embed
        const muteEmbed = {
          color: 0x9C59B6,
          title: 'New Mute',
          description: `Player: \`${playerName}\`\nReason: \`${reason}\`\nDuration: \`${duration.replace('d', ' days').replace('m', ' minutes').replace('M', ' months')}\` (expires/expired ${discordTimestamp})\nOffset: \`${randomOffset}\` μs`,
          footer: {
            icon_url: `https://visage.surgeplay.com/face/64/${playerUUID}`,
            text: playerUUID,
            hover: {
              text: playerName,
            },
          },
        };

        // Check if there are any attachments in the message
        if (message.attachments.size > 0) {
          // Concatenate all attachment URLs into a single string
          const attachmentUrls = message.attachments.map(attachment => attachment.url).join('\n');
          muteEmbed.image = { url: attachmentUrls };
        }

        // Specify the correct webhook URL with the webhook ID and token
        const webhookID = '1193841250659479572'; // Replace WEBHOOK_ID
        const webhookToken = '8tuN8-rjZ7oyywiAHyqpXGBDaKK0Ur2t0PCL2t3aU6SbrG6G-lT43HMSlu8WcslCFoes'; // Replace WEBHOOK_TOKEN
        const webhookURL = `https://discord.com/api/webhooks/${webhookID}/${webhookToken}`;

        muteEmbed.url = `https://minemen.club/player/${playerName}`;

        // Send the embed to the specified webhook
        await s4d.client.api.webhooks(webhookID, webhookToken).post({
          data: {
            embeds: [muteEmbed],
          },
        });

      }
    }
  });


  s4d.client.on('messageCreate', async (message) => {
    if (message.channel.id === '1191447985058500679') {
      const regex = /^\/tb (\S+) (\d+[dhmM]) (.+)$/;
      const match = message.content.match(regex);

      if (match) {
        const playerName = match[1];
        const reasonWithLinks = match[3];
        const duration = match[2];

        const linkRegex = /https?:\/\/\S+/gi;
        const evidenceLinks = (reasonWithLinks.match(linkRegex) || []).join('\n');
        const reason = reasonWithLinks.replace(linkRegex, '').trim();

        const mojangApiUrl = `https://api.mojang.com/users/profiles/minecraft/${playerName}`;
        let playerUUID;
        try {
          const response = await axios.get(mojangApiUrl);
          playerUUID = response.data.id;
        } catch (error) {
          console.error(`Failed to fetch UUID for player ${playerName}`);
          return;
        }

        function calculateExpirationDate(duration) {
          const now = moment();
          const matches = duration.match(/^(\d+)([dhmM])$/);
          if (!matches) {
            throw new Error(`Invalid duration format: ${duration}`);
          }

          const value = parseInt(matches[1]);
          const unit = matches[2];

          let expirationDate;
          switch (unit) {
            case 'd':
              expirationDate = now.add(value, 'days');
              break;
            case 'h':
              expirationDate = now.add(value, 'hours');
              break;
            case 'm':
              expirationDate = now.add(value, 'minutes');
              break;
            case 'M':
              expirationDate = now.add(value, 'months');
              break;
            default:
              throw new Error(`Unsupported unit: ${unit}`);
          }

          return expirationDate;
        }

        const expirationDate = calculateExpirationDate(duration);
        const discordTimestamp = `<t:${Math.floor(expirationDate.unix())}:R>`;

        const formattedDuration = duration.replace('d', ' days').replace('m', ' minutes').replace('M', ' months').replace('h', ' hours');

        const randomOffset = (Math.random() * (5000 - 500) + 500).toFixed(2);

        const tempbanEmbed = {
          color: 0x9C59B6,
          title: 'New Ban',
          description: `Player: \`${playerName}\`\nReason: \`${reason}\`\nDuration: \`${formattedDuration}\` (expires/expired ${discordTimestamp})\nOffset: \`${randomOffset}\` μs${evidenceLinks ? `\n\nEvidence:\n${evidenceLinks}` : ''}`,
          footer: {
            icon_url: `https://visage.surgeplay.com/face/64/${playerUUID}`,
            text: playerUUID,
            hover: {
              text: playerName,
            },
          },
        };

        if (message.attachments.size > 0) {
          const attachmentUrls = message.attachments.map(attachment => attachment.url).join('\n');
          tempbanEmbed.image = { url: attachmentUrls };
        }

        const webhookID = '1193841250659479572';
        const webhookToken = '8tuN8-rjZ7oyywiAHyqpXGBDaKK0Ur2t0PCL2t3aU6SbrG6G-lT43HMSlu8WcslCFoes';
        const webhookURL = `https://discord.com/api/webhooks/${webhookID}/${webhookToken}`;

        tempbanEmbed.url = `https://minemen.club/player/${playerName}`;

        await s4d.client.api.webhooks(webhookID, webhookToken).post({
          data: {
            embeds: [tempbanEmbed],
          },
        });
      }
    }
  });

  s4d.client.on('messageCreate', async (message) => {
    // Check if the message is in the specified channel
    if (message.channel.id === '1191447985058500679') {
      // Check if the message matches the specified format
      const regex = /^\/b (\S+) (.+)$/;
      const match = message.content.match(regex);

      if (match) {
        // Extract relevant information from the matched message
        const playerName = match[1];
        const reason = match[2];

        // Fetch the Minecraft UUID using the Mojang API
        const mojangApiUrl = `https://api.mojang.com/users/profiles/minecraft/${playerName}`;
        let playerUUID;
        try {
          const response = await axios.get(mojangApiUrl);
          playerUUID = response.data.id;
        } catch (error) {
          console.error(`Failed to fetch UUID for player ${playerName}`);
          return;
        }

        // Generate a random offset between 500 and 5000 with two decimal points
        const randomOffset = (Math.random() * (5000 - 500) + 500).toFixed(2);

        // Create the embed
        const banEmbed = {
          color: 0x9C59B6,
          title: 'New Ban',
          description: `Player: \`${playerName}\`\nReason: \`${reason}\`\nDuration: \`Permanent\`\nOffset: \`${randomOffset}\` μs`,
          footer: {
            icon_url: `https://visage.surgeplay.com/face/64/${playerUUID}`,
            text: playerUUID,
            hover: {
              text: playerName,
            },
          },
        };

        // Check if there are any attachments in the message
        if (message.attachments.size > 0) {
          // Concatenate all attachment URLs into a single string
          const attachmentUrls = message.attachments.map(attachment => attachment.url).join('\n');
          banEmbed.image = { url: attachmentUrls };
        }

        // Specify the correct webhook URL with the webhook ID and token
        const webhookID = '1193841250659479572'; // Replace WEBHOOK_ID
        const webhookToken = '8tuN8-rjZ7oyywiAHyqpXGBDaKK0Ur2t0PCL2t3aU6SbrG6G-lT43HMSlu8WcslCFoes'; // Replace WEBHOOK_TOKEN
        const webhookURL = `https://discord.com/api/webhooks/${webhookID}/${webhookToken}`;

        banEmbed.url = `https://minemen.club/player/${playerName}`;

        // Send the embed to the specified webhook
        await s4d.client.api.webhooks(webhookID, webhookToken).post({
          data: {
            embeds: [banEmbed],
          },
        });

      }
    }
  });

  function calculateExpirationDate(duration) {
    const durationValue = parseInt(duration);
    if (duration.includes('d')) {
      return moment().add(durationValue, 'days');
    } else if (duration.includes('m')) {
      return moment().add(durationValue, 'minutes');
    } else if (duration.includes('M')) {
      return moment().add(durationValue, 'months');
    } else {
      // Default to days if no unit is specified
      return moment().add(durationValue, 'days');
    }
  }

  s4d.client.on('messageCreate', async (message) => {
    if (message.content === '^^ticket') {
      const embedInformation = {
        color: 0x1B1C21,
        title: '<:bleach:1180978397078360215> Create a Ticket',
        description: 'Are you experiencing issues with the bot, or want to purchase/upgrade your current tier? Click one of the following buttons to open a ticket accordingly, and our staff will assist you.\n\n',
      };

      const row = new s4d.Discord.MessageActionRow()
        .addComponents(
          new s4d.Discord.MessageButton()
            .setCustomId('apply_staff_normal')
            .setLabel('Purchase')
            .setEmoji('<:purchase:1181246067069681815>')
            .setStyle('SECONDARY'),
          new s4d.Discord.MessageButton()
            .setCustomId('apply_staff_content_creator')
            .setLabel('Support')
            .setEmoji('<:support:1181248199193804972>')
            .setStyle('SECONDARY'),
        );

      message.channel.send({ embeds: [embedInformation], components: [row] });
    }
  });

  s4d.client.on('interactionCreate', async (interaction) => {
    console.log('Interaction ID:', interaction.id);
    console.log('Custom ID:', interaction.customId);

    if (interaction.isButton()) {
      if (interaction.customId === 'apply_staff_normal') {
        await handleApplication(interaction, '1181196253267243028', ['1181019480424452167']);
      } else if (interaction.customId === 'apply_staff_content_creator') {
        await handleApplication(interaction, '1181195859334021241', ['1181019480424452167', '1181023828902678578']);
      } else if (interaction.customId === 'deny_application' && interaction.member.roles.cache.has('1181023828902678578')) {
        // Handle denial logic
        const denialEmbed = {
          color: '#DA373C',
          title: 'Ticket Closed',
          description: 'Channel will be deleted in a few seconds.',
        };
        await interaction.reply({ embeds: [denialEmbed] });

        // Deny permission for role '1181023828902678578' to send messages
        const deniedRole = interaction.guild.roles.cache.get('1181023828902678578');
        if (deniedRole) {
          await interaction.channel.permissionOverwrites.edit(deniedRole, {
            SEND_MESSAGES: false,
          });
        }

        setTimeout(async () => {
          await interaction.channel.delete();
        }, 5 * 1000); // 5 seconds in milliseconds
      } else {
        // Handle unauthorized users
        const unauthorizedEmbed = {
          color: '#1B1C21',
          description: '<:invalid:1181035689383579698> Only assigned users may alter the status of tickets.',
        };
        await interaction.reply({ ephemeral: true, embeds: [unauthorizedEmbed] });
      }
    }
  });

  async function handleApplication(interaction, categoryID, roleIDs) {
    const member = interaction.member;
    const username = member.user.username;

    // Create a new channel under the determined category
    const channel = await interaction.guild.channels.create(`🎫┃${username}`, {
      type: 'text',
      parent: categoryID,
      permissionOverwrites: [
        {
          id: interaction.guild.roles.everyone,
          deny: ['VIEW_CHANNEL'],
        },
        {
          id: member.id,
          allow: ['VIEW_CHANNEL'],
        },
        ...roleIDs.map(roleID => ({
          id: roleID,
          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
        })),
      ],
    });

    const denyButton = new s4d.Discord.MessageButton()
      .setCustomId('deny_application')
      .setLabel('Close')
      .setStyle('DANGER');

    const row = new s4d.Discord.MessageActionRow()
      .addComponents(denyButton);

    const embedBody = categoryID === '1181195859334021241'
      ? 'Thank you for creating a ticket. Please provide any information you deem valuable for staff to best assist you.'
      : 'Thank you for your interest in purchasing Bleach. Please wait, and a senior staff member will be with you momentarily.';

    const embedInformation = {
      color: 0x1B1C21,
      title: `<:ticket:1181200964577918996> ${username}'s Ticket`,
      description: embedBody,
    };

    const sentEmbed = await channel.send({ embeds: [embedInformation], components: [row] });

    // Send an ephemeral embed tagging the created channel
    const ephemeralEmbed = {
      color: 0x1B1C21,
      description: `<#${channel.id}>`,
    };
    await interaction.reply({ ephemeral: true, embeds: [ephemeralEmbed] });
  }

  s4d.client.on('guildMemberAdd', (member) => {
    const roleId = '1181023863413424188'; // Replace with the actual role ID
    const role = member.guild.roles.cache.get(roleId);
    if (role) {
      member.roles.add(role);
    }
  });

  const { SlashCommandBuilder } = require('@discordjs/builders');
  const path = require('path');

  const queryCommand = new SlashCommandBuilder()
    .setName('query')
    .setDescription('Queries a specific UUID via the Mojang API.')
    .addStringOption(option =>
      option.setName('uuid')
        .setDescription('The UUID to query.')
        .setRequired(true));

  const snipeCommand = new SlashCommandBuilder()
    .setName('snipe')
    .setDescription('Submit a sniping request.')
    .addStringOption(option =>
      option.setName('username')
        .setDescription('The username to snipe.')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('window')
        .setDescription('The sniping window, (relative time.)')
        .setRequired(true));
  const pingCommand = new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Checks the current latency for the bot.')
  const queueCommand = new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Returns the numeric value of queued snipes.')
  const linkCommand = new SlashCommandBuilder()
    .setName('link')
    .setDescription('Initiate linking process for tying a Microsoft account to a specified user.')
    .addStringOption(option =>
      option.setName('user')
        .setDescription('The user to link.')
        .setRequired(true))
  const streamCommand = new SlashCommandBuilder()
    .setName('stream')
    .setDescription('Sets up a streamed proxy (SOCK5) for the bot.')
    .addStringOption(option =>
      option.setName('ip')
        .setDescription('The IP to stream to.')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('port')
        .setDescription('The port to stream to.')
        .setRequired(true));
  const paymentCommand = new SlashCommandBuilder()
    .setName('payment')
    .setDescription('Outputs address for specified method.')
    .addStringOption(option =>
      option.setName('method')
        .setDescription('Choose the preferred method.')
        .setRequired(true)
        .addChoices(
          { name: 'Litecoin', value: 'ltc' },
          { name: 'Bitcoin', value: 'btc' },
          { name: 'Ethereum', value: 'eth' },
        ));

  s4d.client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
      switch (interaction.commandName) {
        case 'query':
          // Extract the uuid from the user input
          const uuid = interaction.options.getString('uuid');

          // Make a request to the Mojang API with the provided UUID
          const apiUrl = `https://api.minetools.eu/profile/${uuid}`;
          const response = await fetch(apiUrl);

          // Check if the request was successful
          if (response.ok) {
            const data = await response.json();

            // Create an embed using the data from the API response
            const embedQuery = {
              color: 0x1B1C21,
              title: `<:search:1181205493822275615> ${uuid}`,
              description: `\`\`\`\n${JSON.stringify(data, null, 2)}\`\`\``,
            };

            // Set the URL for the title hyperlink
            embedQuery.url = `https://mine.ly/${uuid}`;

            interaction.reply({ embeds: [embedQuery], ephemeral: true });
          } else {
            interaction.reply({ content: 'Error querying Mojang API', ephemeral: true });
          }
          break;
      }
    }
  });

  s4d.client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
      switch (interaction.commandName) {
        case 'snipe':
          // Check if the user has one of the specified roles
          const allowedRoles = [
            '1181252162022547517',
            '1181252219153170492',
            '1181252247863177216',
            '1181019480424452167',
          ];

          const userRoles = interaction.member.roles.cache.map((role) => role.id);

          if (!allowedRoles.some((role) => userRoles.includes(role))) {
            // Send an error embed for unauthorized users
            const unauthorizedEmbed = {
              color: 0x1B1C21,
              description:
                '<:invalid:1181035689383579698> You are not within a valid tier. Refer to <#1181604102669607004> to obtain <@&1181252162022547517>, <@&1181252219153170492> or <@&1181252247863177216>.',
            };

            interaction.reply({ embeds: [unauthorizedEmbed], ephemeral: true });
            return; // Exit the function to prevent further execution
          }

          const username = interaction.options.getString('username');
          const window = interaction.options.getString('window');

          // Check if the window string is not 10 characters long
          if (window.length !== 10) {
            // Send an error embed for an invalid window string
            const errorEmbed = {
              color: 0x1B1C21,
              description:
                '<:invalid:1181035689383579698> Invalid drop-window received - please provide a [relative timestamp](https://r.3v.fi/discord-timestamps/), e.g. `1704063600`.',
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return; // Exit the function to prevent further execution
          }

          // Check if the username exists in the specified channel's embeds
          const channelToCheck = s4d.client.channels.cache.get('1181026611777261578');
          if (channelToCheck && channelToCheck.isText()) {
            const messages = await channelToCheck.messages.fetch();
            const usernameExists = messages.some((message) => {
              if (message.embeds.length > 0) {
                const embedDescription = message.embeds[0].description || '';
                return embedDescription.toLowerCase().includes(username.toLowerCase());
              }
              return false;
            });

            if (usernameExists) {
              // Send an embed for existing username
              const existingUsernameEmbed = {
                color: 0x1B1C21,
                description: '<:invalid:1181035689383579698> Received username is already being sniped, or is currently protected.',
              };

              interaction.reply({ embeds: [existingUsernameEmbed], ephemeral: true });
              return;
            }
          } else {
            console.error("Error: Channel not found or not a text channel");
            return;
          }

          // Send a pending embed
          const pendingEmbed = {
            color: 0x1B1C21,
            description: '<:pending:1181001895851081850> Request pending...',
          };

          try {
            // Reply with the pending embed and store the returned message
            const pendingMessage = await interaction.reply({ embeds: [pendingEmbed], ephemeral: true });

            // Simulate a delay (5-8 seconds)
            await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * 3000) + 5000));

            // Determine the highest ranking role among the allowed roles
            const highestRole = interaction.member.roles.cache
              .filter((role) => allowedRoles.includes(role.id))
              .sort((a, b) => b.position - a.position)
              .first();

            // Edit the original interaction response with the sniping information
            const snipeEmbed = {
              color: 0x1B1C21,
              title: '<:bleach:1180978397078360215> Sniping Request Queued',
              description: `<:user:1181001358556536903> Username: ${username}\n<:time:1181001357143068783> Window: <t:${window}:F>\n<:tier:1181258727890899055> Tier: ${highestRole}\n<:credits:1181003612852330626> Credits used: 0`,
            };

            await interaction.editReply({ embeds: [snipeEmbed] });

            // Send an additional embed to the specified channel
            const additionalEmbed = {
              color: 0x1B1C21,
              title: `<:bleach:1180978397078360215> Sniping Request Queued`,
              description: `<:user:1181001358556536903> Username: ${username}\n<:at:1181026832133406751> By: <@${interaction.user.id}>`,
            };

            // Get the channel by ID and send the additional embed
            const additionalChannel = s4d.client.channels.cache.get('1181026611777261578');
            if (additionalChannel) {
              additionalChannel.send({ embeds: [additionalEmbed] });
            } else {
              console.error("Error: Channel not found");
            }
          } catch (error) {
            console.error("Error replying to interaction:", error);
          }
          break;
      }
    }
  });
  s4d.client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
      switch (interaction.commandName) {
        case 'ping':
          // Simulate a random ping value between 20 and 60 milliseconds
          const pingValue = Math.floor(Math.random() * (60 - 20 + 1)) + 20;

          // Create and send the ping embed
          const pingEmbed = {
            color: 0x1B1C21,
            description: `<:ping:1181024724483051682> Returning ~\`${pingValue}\` ms.`,
          };

          interaction.reply({ embeds: [pingEmbed], ephemeral: true });
          break;
      }
    }
  });
  s4d.client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
      switch (interaction.commandName) {
        case 'queue':
          // Get the channel by ID
          const queueChannel = s4d.client.channels.cache.get('1181026611777261578');

          if (queueChannel && queueChannel.isText()) {
            // Retrieve the messages in the channel
            const messages = await queueChannel.messages.fetch();

            // Count the number of usernames
            const usernamesCount = messages.size;

            // Create and send the queue embed
            const queueEmbed = {
              color: 0x1B1C21,
              description: `<:snipe:1181030020144185354> Currently sniping \`${usernamesCount}\` username(s) in <#1181026611777261578>.`,
            };

            interaction.reply({ embeds: [queueEmbed], ephemeral: true });
          } else {
            console.error("Error: Channel not found or not a text channel");
          }
          break;
      }
    }
  });
  s4d.client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
      switch (interaction.commandName) {
        case 'link':
          // Get the mentioned user
          const user = interaction.options.getString('user');

          // Create and send the link embed
          const linkEmbed = {
            color: 0x1B1C21,
            title: '<:creeper:1181598776142602270> Linking',
            description: `Process has been initiated for ${user}.\n\n<:bullet:1181599773850079312>Please upload a raw text file *(.txt)* with your Microsoft \`email:password\` in the first line. Your file should look something like the image shown. If you feel unsure about entering your details in a text file, feel free to manually login with your account using our gateway below.`,
            image: {
              url: 'https://i.ibb.co/6wD611c/4165812c5a112ec99b60eab97767b8ec.png',
            },
          };

          // Add the 'Gateway' button with emoji using s4d.Discord.MessageButton
          const gatewayButton = new s4d.Discord.MessageButton()
            .setLabel('Gateway')
            .setStyle('LINK') // Redirects to the provided URL
            .setURL('https://cdn.mtdv.me/video/rick.mp4') // Replace with the actual gateway URL
            .setEmoji('1181735993162858528'); // Replace with the actual emoji ID

          const linkMessage = await interaction.reply({
            embeds: [linkEmbed],
            components: [
              new s4d.Discord.MessageActionRow().addComponents(gatewayButton),
            ],
            ephemeral: false,
          });

          // Listen for file uploads in the same channel
          const filter = (message) => {
            return message.channel.id === interaction.channel.id && message.attachments.size > 0;
          };

          const collector = interaction.channel.createMessageCollector({ filter, time: 60000 }); // Timeout after 1 minute

          collector.on('collect', async (message) => {
            // Create and send the success embed
            const successEmbed = {
              color: 0x1B1C21,
              description: `<:check:1181208933621321861> Account successfully linked to ${user}.`,
            };

            await interaction.followUp({ embeds: [successEmbed], ephemeral: false });
            collector.stop(); // Stop listening after success
          });

          collector.on('end', (collected, reason) => {
            if (reason === 'time') {
              // Handle timeout if needed
              console.log('File upload timeout');
            }
          });
          break;
      }
    }
  });
  s4d.client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
      switch (interaction.commandName) {
        case 'stream':
          const ip = interaction.options.getString('ip', true);
          const port = interaction.options.getString('port', true);

          const pendingEmbed = {
            color: 0x1B1C21,
            description: '<:pending:1181001895851081850> Venting stream...',
          };

          try {
            // Reply with the pending embed and store the returned message
            const pendingMessage = await interaction.reply({ embeds: [pendingEmbed], ephemeral: true });

            // Simulate a delay (5-8 seconds)
            await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * 3000) + 5000));

            // Edit the original interaction response with the stream information
            const streamEmbed = {
              color: 0x1B1C21,
              description: `<:stream:1181936215814045818> Stream added, IP: \`${ip}\`, port: \`${port}\`, NAT type: \`Moderate\`.`,
            };

            await interaction.editReply({ embeds: [streamEmbed] });
          } catch (error) {
            console.error("Error replying to interaction:", error);
          }
          break;
        case 'payment':
          const roleId = '1181023828902678578';
          const member = interaction.guild.members.cache.get(interaction.user.id);

          if (!member.roles.cache.has(roleId)) {
            const embed = new MessageEmbed()
              .setColor(0x1B1C21)
              .setDescription('<:support:1181248199193804972> Only staff may use this command!');
            interaction.reply({ embeds: [embed] });
          } else {
            const methodOption = interaction.options.getString('method');
            let embed;

            switch (methodOption) {
              case 'ltc':
                embed = new MessageEmbed()
                  .setColor(0x1B1C21)
                  .setDescription('<:ltc:1186288133634002984> `LTC123123123`');
                break;

              case 'btc':
                embed = new MessageEmbed()
                  .setColor(0x1B1C21)
                  .setDescription('<:btc:1186288131809476658> `BTC123123123`');
                break;

              case 'eth':
                embed = new MessageEmbed()
                  .setColor(0x1B1C21)
                  .setDescription('<:eth:1186288128730873887> `ETH123123123`');
                break;
            }

            interaction.reply({ embeds: [embed] });
          }
          break;
      }
    }
  });

  s4d.client.on('ready', async () => {
    await s4d.client.application.commands.set([queryCommand, snipeCommand, pingCommand, queueCommand, linkCommand, streamCommand, paymentCommand]);
    console.log('Slash commands registered!');
  });

  return s4d
})();

const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('Bleach server is alive.'));

app.listen(port, () =>
  console.log(`Your app is listening to http://localhost:${port}.`)
);